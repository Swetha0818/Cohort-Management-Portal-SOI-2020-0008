﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;


namespace TribeAcc.Models
{
    public class Event
    {
        public int EventId { get; set; }


        [Required(ErrorMessage = "Enter Event Name")]
        [StringLength(50, ErrorMessage = "Maximum is 50 characters")]
        public string EventName { get; set; }


        [Required(ErrorMessage = "Please enter Date/Time")]
        [DataType(DataType.DateTime)]
        public DateTime EventDT { get; set; }

        [Required(ErrorMessage = "Enter Event Venue")]
        [StringLength(50, ErrorMessage = "Maximum is 50 characters")]
        public string EventVenue { get; set; }

        [Required(ErrorMessage = "Please enter Event Description")]
        [StringLength(2000, ErrorMessage = "Max 2000 chars")]
        public string EventDesc { get; set; }

    }
}
