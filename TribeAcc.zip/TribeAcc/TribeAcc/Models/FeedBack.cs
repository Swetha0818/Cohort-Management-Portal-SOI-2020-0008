﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TribeAcc.Models
{
    public class FeedBack
    {

        public int FeedbackId { get; set; }

        [Required(ErrorMessage = "Please enter your User Id")]
        public int UserId { get; set; }

        [Required(ErrorMessage = "Please enter your Event Id")]
        public int EventId { get; set; }

        public DateTime Submission_Date { get; set; }

        [Required(ErrorMessage = "Please select Feedback Type")]
        public string Feedback_Type { get; set; }

        [Required(ErrorMessage = "Please select Rating")]
        public string Rating { get; set; }


        [Required(ErrorMessage = "Please enter your comment")]
        public string Feedback_Comment { get; set; }
    }
}
