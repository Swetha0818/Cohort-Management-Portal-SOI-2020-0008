﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;


namespace TribeAcc.Models
{
   public class Attendance
   {
      public int AttendanceId { get; set; }
      [Required(ErrorMessage = "Please enter Event Id.")]
      public int EventId { get; set; }
      [Required(ErrorMessage = "Please enter User Id.")]
      public int UserId { get; set; }
      [Required(ErrorMessage = "Please enter User's Status for the event.")]
      
      public string Status { get; set; }
      //public string Email { get; set; }


   }
}
