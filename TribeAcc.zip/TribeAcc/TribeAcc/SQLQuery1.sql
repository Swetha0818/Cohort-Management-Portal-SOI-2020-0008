﻿CREATE TABLE Event
(
   EventId     INT IDENTITY (1, 1) NOT NULL,
   EventName   VARCHAR(50) NOT NULL,
   EventDT   DATETIME NOT NULL,
   EventVenue  VARCHAR(50) NOT NULL,
   EventDesc   VARCHAR(2000) NOT NULL,
   PRIMARY KEY CLUSTERED (EventId ASC),  	
  
);

SET IDENTITY_INSERT Event ON;
INSERT INTO Event(EventId, EventName, EventDT, EventVenue, EventDesc) VALUES
(1,  'Lunch With A Start-Up Successor',    '2021-03-20 14;00', 'Zoom',               'This is a casual and fun-filled session where we catch-up with a world-wide successful startup sucesssor'),
(2,  'Start-up Lecture Series',            '2021-04-26 13;00', 'Zoom',               'This event will allow you to gain insights on existing start-ups and what allowed them to succed. Get ready to hear their inspiring stories!'),
(3,  'Coronavirus Battle',                 '2021-03-08 17:00', 'Zoom',               'Do you have an idea or your product supports people in fighting the Coronavirus then this event is for you!'),
(4,  'Mitigating Risks',                   '2021-06-01 14:30', 'Tribe Accelerator Hub',  'This event is a seminar-based.'),
(5,  'Catalysing Pitch Ideas',             '2021-03-01 15:30', 'Zoom',               'What do we have in common with startups? A burning spirit of venture and innovation. Attend this event at the comfort of your home to learn the tips & tricks to fine-tune your business idea.'),
(6,  'Mitigating Risks',                   '2021-03-23 16:00', 'Tribe Accelerator Hub',  'This event is a seminar-based.'),
(7,  'Biggest Reason why Startups Succeed:Bill Gross', '2021-03-22 17:00', 'Zoom',  'We bring you the Founder & Incubator of dozens of startupss through Zoom to focus on the five key factors that contribute to a start-up success!'),
(8,  'Lunch With A Start-Up Successor',    '2021-04-20 14:00', 'Zoom',               'This is a casual and fun-filled session where we catch-up with a world-wide successful startup sucesssor'),
(9,  'Policy Dialogue',                    '2021-03-08 20:00', 'Tribe Accelerator Hub',     'Are you stuck with a certain business process? Then this event is exactly for you!'),
(10, 'Driving Producitvity & Revenue Through Tech', '2021-03-10 20:00', 'Zoom', 'Come and Join us in learning how cloud solutions can aid you with enhancing the producitivty and revenue of your startup! We will demonstrate products and solutions too!');
SET IDENTITY_INSERT Event OFF;  