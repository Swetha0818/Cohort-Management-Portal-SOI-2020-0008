﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using TribeAcc.Models;

namespace TribeAcc.Controllers
{
    public class RegisterController : Controller
    {
        [AllowAnonymous]
        public IActionResult About()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View("RegisterEvent");
        }



        [Authorize(Roles = "startupfounder, alumni")]
        [HttpGet]
        public IActionResult RegisterEvent()
        {

            List<Event> list = DBUtl.GetList<Event>("SELECT * FROM Event WHERE Event.eventId =  Event.eventId");
            return View(list);
        }

        [Authorize(Roles = "startupfounder, alumni")]
        [HttpGet]
        public IActionResult RegisteredEvent()
        {

            List<Register> list = DBUtl.GetList<Register>("SELECT * FROM Register WHERE Status='Registered' AND UserId='2'");
            return View(list);
        }

        [Authorize(Roles = "startupfounder, alumni")]
        [HttpGet]
        public IActionResult AttendedEvent()
        {

            List<Register> list = DBUtl.GetList<Register>("SELECT * FROM Register WHERE Status='Attended' AND UserId='2'");
            return View(list);
        }

        [HttpGet]
        [Authorize(Roles = "startupfounder, alumni")]

        public IActionResult Create()
        {
            return View("Registration");
        }

        [HttpPost]
        [Authorize(Roles = "startupfounder, alumni")]
        public IActionResult Registration(Register rg)
        {
            IFormCollection form = HttpContext.Request.Form;
            string EventId = form["EventId"].ToString().Trim();
            string UserId = form["UserId"].ToString().Trim();
            string Status = form["Status"].ToString().Trim();


            if (ValidUtl.CheckIfEmpty(EventId, UserId, Status))
            {
                ViewData["Message"] = "Please enter all fields";
                ViewData["MsgType"] = "warning";
                return View("Registration");
            }
            else
            {

                string sql = @"INSERT INTO Register(EventId, UserId, Email, Status) 
                        VALUES({0}, {1}, '{2}', '{3}')";
                if (DBUtl.ExecSQL(sql, rg.EventId, rg.UserId, rg.Email, rg.Status) == 1)
                {
                    string template = @"Hi!<br/><br/>
                               Thank you for registering this event under Tribe Accelerator.
                               Hope to see you there!
                               <br/><br/>Yours Sincerely, TribeAcc.";
                    string title = "Event Registration Successful";
                    string message = String.Format(template);
                    string result;
                    if (EmailUtl.SendEmail(rg.Email, title, message, out result))
                    {
                        TempData["Message"] = "Event Successfully Registered. An email will be sent to you.";
                        TempData["MsgType"] = "success";
                    }

                    else
                    {
                        TempData["Message"] = result;
                        TempData["MsgType"] = "warning";
                    }

                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
                return RedirectToAction("RegisteredEvent");
            }
        }

        [HttpGet]
        [Authorize(Roles = "startupfounder, alumni")]
        public IActionResult Registration(int id)
        {
            string sql = "SELECT EventId FROM Event WHERE Event.EventId ={0}";
           // string sql = "SELECT f.UserId, e.EventId FROM Event e INNER JOIN Feedback f ON Event.EventId = Feedback.EventId WHERE Event.EventId={0}";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                Register register = new Register
                {
                   
                    EventId = (int)dt.Rows[0]["EventId"],
                };
                return View(register);
            }
            else
            {
                return RedirectToAction("RegisteredEvent");
            }

        }

        /*[Authorize(Roles = "startupfounder, alumni")]
        [HttpGet]
        public IActionResult Update(int id)
        {
            string select = "SELECT * FROM Register WHERE RegisterId={0}";
            List<Register> list = DBUtl.GetList<Register>(select, id);
            if (list.Count == 1)
            {
                return View(list[0]);
            }
            else
            {
                TempData["Message"] = "User not found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("RegisteredEvent");
            }
        }


        [Authorize(Roles = "startupfounder, alumni")]
        [HttpPost]
        public IActionResult Update(Register rg)
        {

            {

                string update =
                   @"UPDATE Register
                    SET EventId= {1}, UserId={2}, 
                        Email='{3}', Status='{4}'
                  WHERE RegisterId = {0}";
                int res = DBUtl.ExecSQL(update, rg.RegisterId, rg.EventId, rg.UserId,
                                                rg.Email, rg.Status);
                if (res == 1)
                {
                    string template = @"Hi!<br/><br/>
                               Thank you for registering this event under Tribe Accelerator.
                               Hope to see you there!
                               <br/><br/>Yours Sincerely, TribeAcc.";
                    string title = "Event Registration Successful";
                    string message = String.Format(template);
                    string result;
                    if (EmailUtl.SendEmail(rg.Email, title, message, out result))
                    {
                        ViewData["Message"] = "Event Successfully Registered. An email will be sent to you.";
                        ViewData["MsgType"] = "success";
                    }

                    else
                    {
                        ViewData["Message"] = result;
                        ViewData["MsgType"] = "warning";
                    }

                }
                else
                {
                    ViewData["Message"] = DBUtl.DB_Message;
                    ViewData["MsgType"] = "danger";
                }
                return RedirectToAction("RegisteredEvent");

            }

        }*/


        /*[Authorize(Roles = "startupfounder, alumni")]
        public IActionResult AttendedEvent(int id)
        {
            string update = "UPDATE FROM Register WHERE RegisterId= {0}";
            int res = DBUtl.ExecSQL(update, id);
            if (res == 1)
            {
                TempData["Message"] = "Event Status Updated";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }

            return RedirectToAction("AttendedEvent");
        }*/
    }
}