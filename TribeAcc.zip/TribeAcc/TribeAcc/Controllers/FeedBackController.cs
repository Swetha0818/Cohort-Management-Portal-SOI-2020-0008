﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using TribeAcc.Models;



namespace TribeAcc.Controllers
{
    public class FeedBackController : Controller
    {


        [AllowAnonymous]
        public IActionResult About()
        {
            return View();
        }


        // GET: /<controller>/
        public IActionResult FeedBack()
        {
            return View("ListFeedback");
        }

        public IActionResult AttendedEvent()
        {
            return View("href = '/Register/AttendedEvent' ");
        }
        

        public IActionResult OwnFeedBack()
        {
            return View("GetOwnListFeedback");
        }



        [Authorize(Roles = "staff, startupfounder, alumni")]
        [HttpGet]
        public IActionResult ListFeedback()
        {


            List<FeedBack> list = DBUtl.GetList<FeedBack>("SELECT * FROM Feedback WHERE Feedback.FeedbackId = Feedback.FeedbackId");
            return View(list);

        }

        [Authorize(Roles = "startupfounder")]
        [HttpGet]
        public IActionResult AlumniFeedback()
        {


            List<FeedBack> list = DBUtl.GetList<FeedBack>("SELECT * FROM Feedback WHERE Feedback.UserId = '2'");
            return View(list);

        }


        [Authorize(Roles = "startupfounder, alumni")]
        [HttpGet]
        public IActionResult Create()

        {
            return View("AddFeedback");
        }

        [Authorize(Roles = "startupfounder, alumni")]
        [HttpPost]
        public IActionResult AddFeedback(FeedBack fb)
        {
            IFormCollection form = HttpContext.Request.Form;
            string UserId = form["UserId"].ToString().Trim();
            string EventId = form["EventId"].ToString().Trim();
            string Feedback_Type = form["Feedback_Type"].ToString().Trim();
            string Rating = form["Rating"].ToString().Trim();
            string Feedback_Comment = form["Feedback_Comment"].ToString().Trim();
            DateTime now = DateTime.Now;
            string asString = now.ToString("dd MMMM yyyy hh:mm:ss tt");
        //    string test = "hi" + UserId + EventId + asString + Feedback_Type + Rating + Feedback_Comment;

            if (ValidUtl.CheckIfEmpty(UserId, EventId, Feedback_Type, Rating, Feedback_Comment))
            {
                ViewData["Message"] = DBUtl.DB_Message;
                ViewData["MsgType"] = "warning";
                return View("AddFeedback");
            }
            else
            {


                string sql = @"INSERT INTO Feedback(UserId, EventId, Submission_Date, Feedback_Type, Rating, Feedback_Comment)
                            VALUES({0}, {1}, '{2}', '{3}', '{4}', '{5}')";
              //  string insert = String.Format(sql, UserId, EventId, asString, Feedback_Type, Rating, Feedback_Comment);
                //    int res = DBUtl.ExecSQLs(insert);
                if (DBUtl.ExecSQL(sql, fb.UserId, fb.EventId, asString, fb.Feedback_Type, fb.Rating, fb.Feedback_Comment) == 1)
                {
                    TempData["Message"] = "Feedback Added";
                    TempData["MsgType"] = "success";
                    return RedirectToAction("AlumniFeedback");

                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                    return RedirectToAction("AddFeedback");


                }
            }
        }


        [Authorize(Roles = "startupfounder, alumni")]
        [HttpGet]
        public IActionResult Details(int id)
        {
            string sql = @"SELECT EventId
                             FROM Event 
                               WHERE EventId={0}";
            string select = String.Format(sql, id);
            List<Event> list = DBUtl.GetList<Event>(select);
            if (list.Count == 1)
            {
                Event events = list[0];
                return View("AddFeedback", events);
            }
            else
            {
                TempData["Message"] = "Event Record does not exist";
                TempData["MsgType"] = "warning";
                return RedirectToAction("Index");
            }
        }

        [HttpGet]
        [Authorize(Roles = "startupfounder, alumni")]
        public IActionResult AddFeedback(int id)
        {
            // string sql = "SELECT UserId, EventId FROM Register WHERE Register.UserId ={0}";
            string sql = "SELECT UserId, EventId FROM Register WHERE Register.RegisterId ={0}";
            //  string sql = "SELECT f.UserId, r.EventId FROM Feedback f INNER JOIN Register r ON Feedback.UserId = Register.UserId WHERE Feedback.UserId={0}";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                FeedBack feedback = new FeedBack
                {
                    
                    UserId = (int)dt.Rows[0]["UserId"],
                    EventId = (int)dt.Rows[0]["EventId"],
                };
                return View(feedback);
            }
            else
            {
              //  TempData["Message"] = "Feedback Not Found";
              //  TempData["MsgType"] = "warning";
                return RedirectToAction("AttendedEvent");
            }

        }


        [HttpGet]
        [Authorize(Roles = "startupfounder, alumni")]
        public IActionResult EditFeedback(int id)
        {
            string sql = "SELECT * FROM Feedback WHERE FeedbackId={0}";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                FeedBack feedback = new FeedBack
                {
                    FeedbackId = (int)dt.Rows[0]["FeedbackId"],
                    UserId = (int)dt.Rows[0]["UserId"],
                    EventId = (int)dt.Rows[0]["EventId"],
                    Submission_Date = (DateTime)dt.Rows[0]["Submission_Date"],
                    Feedback_Type = dt.Rows[0]["Feedback_Type"].ToString(),
                    Rating = dt.Rows[0]["Rating"].ToString(),
                    Feedback_Comment = dt.Rows[0]["Feedback_Comment"].ToString(),
                };
                return View(feedback);
            }
            else
            {
                TempData["Message"] = "Feedback Not Found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("AlumniFeedback");
            }
        }

        [HttpPost]
        [Authorize(Roles = "startupfounder, alumni")]
        public IActionResult EditFeedback(FeedBack feedback)
        {


            // Update Record in Database  
            string update = @"UPDATE Feedback  
                              SET UserId={1}, EventId={2}, Submission_Date='{3}', Feedback_Type='{4}',
                                  Rating='{5}', Feedback_Comment='{6}'
                            WHERE FeedbackId={0}";

            string asString = feedback.Submission_Date.ToString("dd MMMM yyyy hh:mm:ss tt");
            /*
                        string update = String.Format(sql, feedback.FeedbackId,
                                                           feedback.UserId,   
                                                           feedback.EventId,
                                                           feedback.Submission_Date.ToString("yyyy-MM-dd HH:mm"),
                                                           feedback.Feedback_Type,
                                                           feedback.Rating,
                                                           feedback.Feedback_Comment);
                                                           */


            int count = DBUtl.ExecSQL(update, feedback.FeedbackId, feedback.UserId, feedback.EventId, asString, feedback.Feedback_Type, feedback.Rating, feedback.Feedback_Comment);
            if (count == 1)
            {
                TempData["Message"] = "Feedback Has Been Successfully Updated!";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("AlumniFeedback");
        }




        [Authorize(Roles = "alumni,startupfounder")]
        public IActionResult DeleteFeedback(int id)
        {
            string select = @"SELECT * FROM Feedback
                              WHERE FeedbackId={0}";
            DataTable ds = DBUtl.GetTable(select, id);
            if (ds.Rows.Count != 1)
            {
                TempData["Message"] = "Feedback record no longer exists.";
                TempData["MsgType"] = "warning";
            }
            else
            {
                string delete = "DELETE FROM Feedback WHERE FeedbackId={0}";
                int res = DBUtl.ExecSQL(delete, id);
                if (res == 1)
                {
                    TempData["Message"] = "Feedback Deleted";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
            }
            return RedirectToAction("AlumniFeedback");
        }

    }
}







