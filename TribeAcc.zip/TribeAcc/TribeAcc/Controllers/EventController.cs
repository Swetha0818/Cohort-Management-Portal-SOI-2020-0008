﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using TribeAcc.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;



namespace TribeAcc.Controllers
{
    public class EventController : Controller
    {

        [AllowAnonymous]
        public IActionResult About()
        {
            return View();
        }

        [AllowAnonymous]
        public IActionResult gcal()
        {
            return View();
        }


        [Authorize(Roles = "staff, startupfounder, alumni")]
        public IActionResult Event()
        {
            return View("Index");
        }

        [Authorize(Roles = "staff")]
        [HttpGet]
        public IActionResult Index()
        {

            List<Event> list = DBUtl.GetList<Event>("SELECT * FROM Event WHERE Event.eventId =  Event.eventId");
            return View(list);
        }


        [Authorize(Roles = "startupfounder, alumni")]
        public IActionResult RegisterEvent()
        {
            List<Event> list = DBUtl.GetList<Event>("SELECT * FROM Event WHERE Event.eventId =  Event.eventId");
            return View(list);
        }

        [Authorize(Roles = "startupfounder, alumni")]
        public IActionResult Details(int id)
        {
            string sql =
              @"SELECT EventId, EventName, EventDT, EventVenue, EventDesc
                             FROM Event 
                               WHERE EventId={0}";

            string select = String.Format(sql, id);
            List<Event> list = DBUtl.GetList<Event>(select);
            if (list.Count == 1)
            {
                Event events = list[0];
                return View("Details", events);
            }
            else
            {
                TempData["Message"] = "Event Record does not exist";
                TempData["MsgType"] = "warning";
                return RedirectToAction("Index");
            }
        }



     

        #region "Event Add"

        [Authorize(Roles = "staff")]
        public IActionResult AddEvent()
        {
            return View();
        }
        [HttpPost]
        [Authorize(Roles = "staff")]
      
        public IActionResult AddEvent(Event events)
        {
            IFormCollection form = HttpContext.Request.Form;
            string eventName = form["EventName"].ToString().Trim();
            string eventDT = form["EventDT"].ToString().Trim();
            string eventVenue = form["EventVenue"].ToString().Trim();
            string eventDesc = form["EventDesc"].ToString().Trim();

            if (ValidUtl.CheckIfEmpty(eventName, eventDT, eventVenue, eventDesc))
            {
                ViewData["Message"] = "Please enter all fields";
                ViewData["MsgType"] = "warning";
                return View("AddEvent");
            }
            else
            {

                string sql = @"INSERT INTO Event(EventName, EventDT, EventVenue, EventDesc) 
                        VALUES('{0}', '{1:yyyy-MM-dd HH:mm}', '{2}', '{3}')";
                if (DBUtl.ExecSQL(sql, events.EventName, events.EventDT, events.EventVenue, events.EventDesc) == 1)
                {
                    TempData["Message"] = "New Event has been Added!";
                    TempData["MsgType"] = "success";
                    return RedirectToAction("Index");

                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                    return View("AddEvent");
                }
            }
        }
        #endregion
        [HttpGet]
        [Authorize(Roles = "staff")]
        public IActionResult Update(int id)
        {
            string sql = "SELECT * FROM Event WHERE eventId={0}";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                Event events = new Event
                {
                    EventId = (int)dt.Rows[0]["eventId"],
                    EventName = dt.Rows[0]["eventname"].ToString(),
                    EventDT = (DateTime)dt.Rows[0]["eventDT"],
                    EventVenue = dt.Rows[0]["eventVenue"].ToString(),
                    EventDesc = dt.Rows[0]["eventDesc"].ToString(),
                };
                return View(events);
            }
            else
            {
                TempData["Message"] = "Event Not Found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        [Authorize(Roles = "staff")]
        public IActionResult Update(Event events)
        {
            IFormCollection form = HttpContext.Request.Form;
            string eventId = form["EventId"].ToString().Trim();
            string eventName = form["EventName"].ToString().Trim();
            string eventDT = form["EventDT"].ToString().Trim();
            string eventVenue = form["EventVenue"].ToString().Trim();
            string eventDesc = form["EventDesc"].ToString().Trim();


            // Update Record in Database  
            string sql = @"UPDATE Event  
                              SET EventName='{1}', EventDT='{2}', EventVenue='{3}',
                                  EventDesc='{4}'
                            WHERE EventId='{0}'";

            string update = String.Format(sql, events.EventId,
                                               events.EventName.EscQuote(),
                                               events.EventDT.ToString("yyyy-MM-dd HH:mm"),
                                               events.EventVenue.EscQuote(),
                                               events.EventDesc);

            int count = DBUtl.ExecSQL(update);
            if (count == 1)
            {
                TempData["Message"] = "Event Has Been Successfully Updated!";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("Index");
        }


        [Authorize(Roles = "staff")]
        public IActionResult DeleteEvent(int id)
        {
            string select = @"SELECT * FROM Event 
                              WHERE EventId={0}";
            DataTable ds = DBUtl.GetTable(select, id);
            if (ds.Rows.Count != 1)
            {
                TempData["Message"] = "Event record no longer exists.";
                TempData["MsgType"] = "warning";
            }
            else
            {
                string delete = "DELETE FROM Event WHERE EventId={0}";
                int res = DBUtl.ExecSQL(delete, id);
                if (res == 1)
                {
                    TempData["Message"] = "Event Deleted";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
            }
            return RedirectToAction("Index");
        }
       
    }
}

    