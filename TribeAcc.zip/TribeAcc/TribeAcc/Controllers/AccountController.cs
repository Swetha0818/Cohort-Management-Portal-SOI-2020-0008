using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Security.Claims;
using TribeAcc.Models;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace TribeAcc.Controllers
{

   public class AccountController : Controller
   {
      private const string LOGIN_SQL =
         @"SELECT * FROM SysUser 
            WHERE UserName = '{0}'
              AND UserPw = HASHBYTES('SHA1', '{1}')";

      private const string LASTLOGIN_SQL =
         @"UPDATE SysUser SET LastLogin=GETDATE() WHERE UserName= '{0}'";

      private const string ROLE_COL = "UserType";
      private const string NAME_COL = "UserName";

      private const string REDIRECT_CNTR = "Event";
      private const string REDIRECT_ACTN = "About";

      private const string LOGIN_VIEW = "UserLogin";

      [AllowAnonymous]
      public IActionResult Login(string returnUrl = null)
      {
         TempData["ReturnUrl"] = returnUrl;
         return View(LOGIN_VIEW);
      }

      [AllowAnonymous]
      [HttpPost]
      public IActionResult Login(UserLogin user)
      {
         if (!AuthenticateUser(user.UserName, user.Password, out ClaimsPrincipal principal))
         {
            ViewData["Message"] = "Incorrect User ID or Password";
            ViewData["MsgType"] = "warning";
            return View(LOGIN_VIEW);
         }
         else
         {
            HttpContext.SignInAsync(
               CookieAuthenticationDefaults.AuthenticationScheme,
               principal,
           new AuthenticationProperties
           {
              IsPersistent = user.RememberMe
           });

            // Update the Last Login Timestamp of the User
            DBUtl.ExecSQL(LASTLOGIN_SQL, user.UserName);

            if (TempData["returnUrl"] != null)
            {
               string returnUrl = TempData["returnUrl"].ToString();
               if (Url.IsLocalUrl(returnUrl))
                  return Redirect(returnUrl);
            }

            return RedirectToAction(REDIRECT_ACTN, REDIRECT_CNTR);
         }
      }

        [Authorize]
      public IActionResult Logoff(string returnUrl = null)
      {
         HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
         if (Url.IsLocalUrl(returnUrl))
            return Redirect(returnUrl);
         return RedirectToAction(REDIRECT_ACTN, REDIRECT_CNTR);
      }


      [AllowAnonymous]
      public IActionResult Forbidden()
      {
         return View();
      }

      [Authorize(Roles = "staff")]
      public IActionResult Users()
      {
         List<SysUser> list = DBUtl.GetList<SysUser>("SELECT * FROM SysUser WHERE UserType='startupfounder'");
         return View(list);
      }

      [Authorize(Roles = "staff")]
      public IActionResult UsersAlumni()
      {
          List<SysUser> list = DBUtl.GetList<SysUser>("SELECT * FROM SysUser WHERE UserType='alumni'");
          return View(list);
      }

      [Authorize(Roles = "staff")]
      public IActionResult UsersStaff()
      {
          List<SysUser> list = DBUtl.GetList<SysUser>("SELECT * FROM SysUser WHERE UserType='staff'");
          return View(list);
      }



        [Authorize(Roles = "staff")]
        [HttpGet]
        public IActionResult Update(int id)
        {
            string select = "SELECT * FROM SysUser WHERE UserId={0}";
            List<SysUser> list = DBUtl.GetList<SysUser>(select, id);
            if (list.Count == 1)
            {
                return View(list[0]);
            }
            else
            {
                TempData["Message"] = "User not found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("Users");
            }
        }


        [Authorize(Roles = "staff")]
        [HttpPost]
        public IActionResult Update(SysUser usr)
        {
            {
                string update =
                   @"UPDATE SysUser
                    SET UserPw= HASHBYTES('SHA1', '{1}'), UserName='{2}', 
                        Email='{3}', UserType='{4}'
                  WHERE UserId = {0}";
                int res = DBUtl.ExecSQL(update, usr.UserId, usr.UserPw, usr.UserName,
                                                usr.Email, usr.UserType);
                if (res == 1)
                {
                    TempData["Message"] = "User Status Successfully Updated";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
                return RedirectToAction("Users");
            }
        }

     


      [Authorize(Roles = "staff")]
      public IActionResult Delete(int id)
      {
         string delete = "DELETE FROM SysUser WHERE UserId= {0}";
         int res = DBUtl.ExecSQL(delete, id);
         if (res == 1)
         {
            TempData["Message"] = "User Record Deleted";
            TempData["MsgType"] = "success";
         }
         else
         {
            TempData["Message"] = DBUtl.DB_Message;
            TempData["MsgType"] = "danger";
         }

         return RedirectToAction("Users");
      }

      [AllowAnonymous]
      public IActionResult Register()
      {
         return View("UserRegister");
      }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Register(SysUser usr)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("UserRegister");
            }
            else
            {
                string insert =
                   @"INSERT INTO SysUser(UserPw, UserName, Email, UserType) VALUES
                 (HASHBYTES('SHA1', '{0}'), '{1}', '{2}', 'startupfounder')";
                if (DBUtl.ExecSQL(insert, usr.UserPw, usr.UserName, usr.Email) == 1)
                {
                    string template = @"Hi {0},<br/><br/>
                               Welcome to TribeAcc!
                               Below is your login information.
                               Your username is <b>{1}</b> and password is <b>{2}</b>.
                               <br/><br/>Startup Founder.";
                    string title = "Registration Successful - Welcome";
                    string message = String.Format(template, usr.UserName, usr.UserName, usr.UserPw);
                    string result;
                    if (EmailUtl.SendEmail(usr.Email, title, message, out result))
                    {
                        ViewData["Message"] = "User Successfully Registered. An email will be sent to you with your login information attached.";
                        ViewData["MsgType"] = "success";
                    }

                    else
                    {
                        ViewData["Message"] = result;
                        ViewData["MsgType"] = "warning";
                    }

                }
                else
                {
                    ViewData["Message"] = DBUtl.DB_Message;
                    ViewData["MsgType"] = "danger";
                }
                return View("UserRegister");
            }
        }

     
        private bool AuthenticateUser(string UserName, string pw, out ClaimsPrincipal principal)
      {
         principal = null;

         DataTable ds = DBUtl.GetTable(LOGIN_SQL, UserName, pw);
         if (ds != null && ds.Rows.Count > 0)
         {
            principal =
               new ClaimsPrincipal(
                  new ClaimsIdentity(
                     new Claim[] {
                        new Claim(ClaimTypes.Name, ds.Rows[0][NAME_COL].ToString()),
                        new Claim(ClaimTypes.Role, ds.Rows[0][ROLE_COL].ToString())
                     }, "Basic"
                  )
               );
            return true;
         }
         return false;
      }

   }
}