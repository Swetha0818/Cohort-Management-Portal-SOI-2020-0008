﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using TribeAcc.Models;

namespace TribeAcc.Controllers
{
    public class AttendanceController : Controller
    {
        
        [AllowAnonymous]
        public IActionResult About()
        {
            return View();
        }

        public IActionResult Attendance()
        {
            return View("ListAttendance");
        }



        [Authorize(Roles = "staff, startupfounder, alumni")]
        [HttpGet]
        public IActionResult ListAttendance()
        {

            List<Attendance> list = DBUtl.GetList<Attendance>("SELECT * FROM Attendance WHERE Attendance.attendanceId =  Attendance.attendanceId");
            return View(list);
        }



        /*[Authorize(Roles = "startupfounder, alumni")]
        [HttpGet]
        public IActionResult RegisteredEvent()
        {

            List<Attendance> list = DBUtl.GetList<Attendance>("SELECT * FROM Attendance WHERE Attendance.attendanceId =  Attendance.attendanceId");
            return View(list);
        }*/


        #region "Attendance Add"
        [HttpGet]
        [Authorize(Roles = "startupfounder, alumni")]

        public IActionResult AddAttendance(int id)
        {
            /*string sql = "SELECT EventId FROM Event WHERE EventId={0}";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                Attendance attendances = new Attendance
                {
                    //AttendanceId = (int)dt.Rows[0]["AttendanceId"],
                    EventId = (int)dt.Rows[0]["EventId"],
                    UserId = (int)dt.Rows[0]["UserId"],
                    Status = dt.Rows[0]["Status"].ToString()
                };
                return View(attendances);
            }
            else
            {
                TempData["Message"] = "Attendance Not Found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("RegisterEvent");
            }*/
            return View();
        }
        
        [HttpPost]
        [Authorize(Roles = "startupfounder, alumni")]
        public IActionResult AddAttendance(Attendance at)
        {
            IFormCollection form = HttpContext.Request.Form;
            string EventId = form["EventId"].ToString().Trim();
            string UserId = form["UserId"].ToString().Trim();
            string Status = form["Status"].ToString().Trim();


            if (ValidUtl.CheckIfEmpty(EventId, UserId, Status))
            {
                ViewData["Message"] = "Please enter all fields";
                ViewData["MsgType"] = "warning";
                return View("AddAttendance");
            }
            else
            {
            
                string sql = @"INSERT INTO Attendance(EventId, UserId, Status) 
                        VALUES({0}, {1}, '{2}')";
                if (DBUtl.ExecSQL(sql, at.EventId, at.UserId, at.Status) == 1)
                {
                    TempData["Message"] = "Attendance Added";
                    TempData["MsgType"] = "success";
                    return RedirectToAction("ListAttendance");
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                    return View("AddAttendance");
                }
            }
        }
        
     

        [HttpGet]
        [Authorize(Roles = "staff")]
        public IActionResult EditAttendance(int id)
        {
            string sql = "SELECT * FROM Attendance WHERE AttendanceId={0}";
            string select = String.Format(sql, id);
            DataTable dt = DBUtl.GetTable(select);
            if (dt.Rows.Count == 1)
            {
                Attendance attendances = new Attendance
                {
                    AttendanceId = (int)dt.Rows[0]["AttendanceId"],
                    EventId = (int)dt.Rows[0]["EventId"],
                    UserId = (int)dt.Rows[0]["UserId"],
                    Status = dt.Rows[0]["Status"].ToString()
                };
                return View(attendances);
            }
            else
            {
                TempData["Message"] = "Attendance Not Found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("ListAttendance");
            }
        }

        [HttpPost]
        [Authorize(Roles = "staff")]
        public IActionResult EditAttendance(Attendance attendance)
        {
            string update =
                  @"UPDATE Attendance
                    SET EventId={1}, UserId={2}, 
                        Status='{3}'
                  WHERE AttendanceId = {0}";
            int res = DBUtl.ExecSQL(update, attendance.AttendanceId, attendance.EventId, attendance.UserId,
                                            attendance.Status);
            if (res == 1)
            {
                TempData["Message"] = "Attendance Status Successfully Updated";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("ListAttendance");
        }

        [Authorize(Roles = "staff")]
        public IActionResult DeleteAttendance(int id)
        {
            string select = @"SELECT * FROM Attendance 
                              WHERE AttendanceId={0}";
            DataTable ds = DBUtl.GetTable(select, id);
            if (ds.Rows.Count != 1)
            {
                TempData["Message"] = "Attendance record no longer exists.";
                TempData["MsgType"] = "warning";
            }
            else
            {
                string delete = "DELETE FROM Attendance WHERE AttendanceId={0}";
                int res = DBUtl.ExecSQL(delete, id);
                if (res == 1)
                {
                    TempData["Message"] = "Attendance Deleted";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
            }
            return RedirectToAction("ListAttendance");
        }

    }
}

#endregion